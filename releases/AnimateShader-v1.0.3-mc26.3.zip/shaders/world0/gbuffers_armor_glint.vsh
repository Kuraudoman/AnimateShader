#version 330 compatibility
#define DIMENSION_OVERWORLD
#include "/program/gbuffers_armor_glint.vsh"
