#version 330 compatibility
#define DIMENSION_END
#include "/program/composite5.fsh"
