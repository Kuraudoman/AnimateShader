#version 330 compatibility
#define DIMENSION_END
#include "/program/gbuffers_armor_glint.vsh"
