#version 330 compatibility
#define DIMENSION_NETHER
#include "/program/gbuffers_textured.fsh"
